﻿using System;

/*
 * Null - совместимые значимые типы (Nullable)
 */

namespace _35_yrok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string str = null;

            int? a = null;

            DateTime? dateTime = null;
        }
    }
}
