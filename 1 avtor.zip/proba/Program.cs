﻿using System;

namespace proba
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("pi");
            Console.ReadLine();
        }
    }
}
