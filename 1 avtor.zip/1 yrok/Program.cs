﻿using System;

namespace _1_yrok
{
    // Однострочный коментарий
    /* многострочный коментарий
     * 
     * 
     */
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!!");

            Console.WriteLine("Привет человек!!");
        }
    }
}
