﻿using System;

namespace _4_yrok
{ // Операторы
  // Арифмитеческие операции с числами
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 4;

            int result = a % b;
            double result2 = (double)a / b;

            Console.WriteLine(result);
            Console.WriteLine(result2);

        }
    }
}
