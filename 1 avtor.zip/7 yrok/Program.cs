﻿using System;

/*
 *  Операторы отношений 
 *  Операции сравнения
 */

/*
 *   == Равно
 *   != Не равно
 *   > Больше
 *   < Меньше
 *   >= Больше или равно
 *   <= Меньше или равно
 */

namespace _7_yrok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 5;

            int b = 4;

            //Console.WriteLine(a == b);

            bool result = a == b;

            Console.WriteLine(result);
        }
    }
}
