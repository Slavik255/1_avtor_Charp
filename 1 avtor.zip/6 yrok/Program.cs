﻿using System;

/*
 * Инкремент и декремент. Постфиксный и префиксный
 */

namespace _6_yrok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 0;

            a++;
            // Или по другому
            ++a;

            Console.WriteLine(a);
        }
    }
}
