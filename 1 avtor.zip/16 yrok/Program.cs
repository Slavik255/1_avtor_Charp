﻿using System;

/*
 * Массивы
 * 
 * Одномерные массивы
 * 
 * Тип_элементов [] имя_массива;
 * 
 * Инициализация массива
 */

namespace _16_yrok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //int[] myArray;
            //myArray = new int[5];

            int[] myArray = new int[5] { 7, 0, 5, 4, 2 };

            //myArray[0] = 10;
            //myArray[1] = 3;

            //int a = myArray[0];

            /*Console.WriteLine(myArray[0]); */
            //Console.WriteLine(a);

            Console.ReadLine();
        }
    }
}
