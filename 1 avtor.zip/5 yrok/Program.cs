﻿using System;

namespace _5_yrok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("fi");
            Console.ReadLine();
        }
    }
}
